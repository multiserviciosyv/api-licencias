
// Proyecto Flutter: App de Almacén (base)
// Estructura con configuración SUNAT, simulación de envío y sistema de licencias con validación remota

import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

void main() {
  runApp(AlmacenApp());
}

class AlmacenApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Sistema de Almacén',
      home: LicenciaCheckScreen(),
    );
  }
}

// ------------------- MODELO DE LICENCIA -------------------
class Licencia {
  String codigo;
  DateTime fechaExpiracion;

  Licencia({required this.codigo, required this.fechaExpiracion});

  bool estaActiva() {
    return DateTime.now().isBefore(fechaExpiracion);
  }
}

Licencia? licenciaActual;

// ------------------- PANTALLA DE VERIFICACIÓN -------------------
class LicenciaCheckScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return licenciaActual == null || !licenciaActual!.estaActiva()
        ? LicenciaActivarScreen()
        : LoginScreen();
  }
}

// ------------------- PANTALLA DE ACTIVACIÓN -------------------
class LicenciaActivarScreen extends StatefulWidget {
  @override
  _LicenciaActivarScreenState createState() => _LicenciaActivarScreenState();
}

class _LicenciaActivarScreenState extends State<LicenciaActivarScreen> {
  final TextEditingController codigoController = TextEditingController();
  bool cargando = false;

  Future<void> activarLicenciaRemota() async {
    final codigo = codigoController.text.trim();
    if (codigo.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Ingrese un código de licencia válido')));
      return;
    }

    setState(() => cargando = true);

    try {
      final response = await http.get(Uri.parse('https://api-licencias.onrender.com/api/licencia/$codigo'));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final fechaExpiracion = DateTime.parse(data['fecha_expiracion']);
        setState(() {
          licenciaActual = Licencia(codigo: codigo, fechaExpiracion: fechaExpiracion);
        });
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => LoginScreen()));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Licencia no válida o expirada')));
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Error de conexión con el servidor')));
    } finally {
      setState(() => cargando = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Activar Licencia')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            const Text('Ingrese su código de licencia para continuar:'),
            TextField(controller: codigoController, decoration: const InputDecoration(labelText: 'Código de Licencia')),
            const SizedBox(height: 20),
            cargando
                ? const CircularProgressIndicator()
                : ElevatedButton(
                    onPressed: activarLicenciaRemota,
                    child: const Text('Validar y Activar'),
                  ),
          ],
        ),
      ),
    );
  }
}

// ------------------- PANTALLA DE LOGIN (DEMO) -------------------
class LoginScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Iniciar Sesión')),
      body: Center(
        child: ElevatedButton(
          child: const Text('Entrar al sistema'),
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const HomeScreen())),
        ),
      ),
    );
  }
}

// ------------------- HOME DEMO -------------------
class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Panel Principal')),
      body: const Center(child: Text('Bienvenido al sistema de almacén')),
    );
  }
}
