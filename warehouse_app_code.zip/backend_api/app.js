
const express = require('express');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());

const licencias = {
  "ABC123": "2025-12-31",
  "XYZ789": "2024-09-01",
  "DEMO456": "2025-06-30"
};

app.get('/api/licencia/:codigo', (req, res) => {
  const codigo = req.params.codigo;
  if (licencias[codigo]) {
    return res.json({
      codigo: codigo,
      fecha_expiracion: licencias[codigo]
    });
  } else {
    return res.status(404).json({ error: 'Licencia no encontrada' });
  }
});

app.listen(PORT, () => {
  console.log(`Servidor escuchando en puerto ${PORT}`);
});
