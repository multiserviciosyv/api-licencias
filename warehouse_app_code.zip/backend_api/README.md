
# API de Licencias - Node.js + Express

Esta API valida licencias de tu aplicación de almacén.

## Uso

```
npm install
npm start
```

Accede a:

```
GET /api/licencia/:codigo
```
